<?php
include('config/config.php');
echo $enterbvn = $_POST['enterbvn'];
echo $enternin = $_POST['enternin'];

?>