package com.mycompany.jun15airbnb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
